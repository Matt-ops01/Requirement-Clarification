# UX/UI Specification Structure

Use this reference only when the user confirms that enough information has been gathered and asks to synthesize the complete UX/UI specification.

## Documentation Rules

- Write in the user's language.
- Use Markdown with clear separators.
- Mark every unresolved decision as `待确认`.
- Separate confirmed decisions from assumptions.
- Include PRD-derived rationale when it affects layout or interaction.
- Prefer implementable descriptions over generic UX advice.
- Use Mermaid for flows with branches; use ASCII only for compact structural sketches.

## Required Structure

### 1. 信息架构 (Information Architecture)

Include:

- 页面层级结构图: route tree, tab hierarchy, or module map.
- 内容分组与组件组织: grouped by user goal and frontend component boundaries.
- 导航结构与模式: global navigation, local navigation, breadcrumbs, tabs, sidebars, drawers, or modal entry points.
- 布局区域划分: header, toolbar, content, side panel, footer, persistent controls, responsive regions.
- 响应式行为规范: desktop/tablet/mobile changes, density rules, hidden/collapsed content, touch behavior.

Suggested formats:

```text
App
├─ Dashboard
│  ├─ Summary cards
│  ├─ Primary list/table
│  └─ Detail drawer
└─ Settings
   ├─ Profile
   └─ Permissions
```

```text
[Header: title/actions]
[Toolbar: search/filter/sort]
[Main: list/table/cards] [Aside: detail/insight]
[Feedback layer: toast/modal/inline error]
```

### 2. 核心用户流程 (Core User Flows)

Include:

- 主要用户路径: step-by-step flow with page and component states.
- 决策点与分支: role differences, optional choices, validation branches.
- 错误状态与恢复路径: empty, invalid, permission denied, network failure, timeout, conflict.
- 流程图: Mermaid text for implementation or design tooling.
- 成功路径可视化: what the user sees after completion and where they land.

Mermaid starter:

```mermaid
flowchart TD
  A[Entry point] --> B{User decision}
  B -->|Primary path| C[Screen state]
  B -->|Error or alternate path| D[Recovery state]
  C --> E[Success confirmation]
```

### 3. 视图规范 (View Specifications)

For each key view include:

- View purpose and primary user intent.
- Entry points and exit paths.
- Layout sketch or region breakdown.
- Component hierarchy and nesting.
- State matrix: loading, empty, data, error, disabled, permission-limited, success.
- Data display pattern: table, card, timeline, form, dashboard, canvas, wizard, comparison, etc.
- Content priority and visual hierarchy.
- Frontend notes: route, props/data dependencies, conditional rendering.

State matrix starter:

| State | UI Behavior | User Action | Frontend Notes |
| --- | --- | --- | --- |
| Loading | Skeleton or spinner placement | Wait/cancel if available | Avoid layout shift |
| Empty | Explain absence and show primary CTA | Create/import/change filters | Needs empty reason |
| Error | Inline or page-level error | Retry/go back/contact support | Preserve user input |
| Success | Confirmation and next best action | Continue/view details | Trigger toast or route change |

### 4. 交互模式 (Interaction Patterns)

Include:

- Inputs and controls: forms, search, filters, sort, upload, date range, selection, bulk actions.
- Feedback mechanisms: inline validation, toast, banner, modal, progress, optimistic update.
- Animation and transitions: route changes, drawer/modal entry, expand/collapse, loading transitions.
- Microinteractions: hover, focus, active, drag, selection, copy, save, undo.
- Gesture support if relevant: swipe, pinch, long press, drag/drop.

### 5. 设计系统集成 (Design System Integration)

Include:

- Component usage rules: buttons, forms, tables, cards, dialogs, drawers, tabs, menus, pagination.
- Grid and spacing principles.
- Typography hierarchy.
- Color and semantic status usage.
- Icon usage and labeling.
- UI pattern consistency rules.
- Any required design system or component library constraints.

### 6. 可访问性 (Accessibility)

Include:

- Keyboard navigation path and tab order.
- Screen reader labels, regions, live announcements, and error messaging.
- Click/touch target sizes.
- Color contrast requirements, ideally WCAG 2.1 AA when not otherwise specified.
- Focus state management across modals, drawers, menus, route changes, and validation.
- Reduced motion considerations.

### 7. 技术实现说明 (Technical Implementation Notes)

Include:

- Frontend component mapping: page, layout, feature, and shared components.
- View state management: local state, server state, URL state, form state, optimistic state.
- Rendering considerations: SSR/CSR needs, pagination/virtualization, skeletons, lazy loading.
- Performance suggestions: bundle splitting, image optimization, memoization, caching, debounced inputs.
- Data and API assumptions: required fields, loading sequence, mutation outcomes.
- Analytics or instrumentation points if implied by the PRD.

## Closing Section

End with:

- `已确认决策`: concise list.
- `关键假设`: decisions inferred but not directly confirmed.
- `待确认问题`: remaining blockers for design or frontend implementation.
- `建议下一步`: prototype, visual design, component build, or validation plan.
